import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "VIPSTAR — продвижение и digital-услуги",
  description: "Каталог digital-услуг, заказы и поддержка VIPSTAR."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}

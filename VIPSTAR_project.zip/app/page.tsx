"use client";

import { useState } from "react";

const services = [
  { icon: "📣", title: "Контент и оформление", desc: "Подготовка публикаций, оформление профиля и контент-план.", price: "от 2 000 ₸", category: "Контент и оформление" },
  { icon: "🎬", title: "Монтаж коротких видео", desc: "Монтаж Reels, Shorts и TikTok из предоставленных материалов.", price: "от 3 000 ₸", category: "Монтаж коротких видео" },
  { icon: "📊", title: "Аналитика соцсетей", desc: "Разбор статистики и рекомендации по развитию аудитории.", price: "от 2 500 ₸", category: "Аналитика соцсетей" },
  { icon: "🎨", title: "Дизайн публикаций", desc: "Обложки, баннеры и визуалы для ваших социальных сетей.", price: "от 1 500 ₸", category: "Дизайн публикаций" },
  { icon: "🗓️", title: "Контент-план", desc: "Идеи и расписание публикаций под тематику проекта.", price: "от 2 000 ₸", category: "Контент-план" },
  { icon: "🤝", title: "Консультация", desc: "Обсудим цели и подберём подходящие легальные способы продвижения.", price: "от 1 000 ₸", category: "Консультация" }
];

export default function Home() {
  const [category, setCategory] = useState(services[0].category);
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [details, setDetails] = useState("");
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  async function submitOrder(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setStatus("");
    try {
      const response = await fetch("/api/orders", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, contact, category, details })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Не удалось отправить заявку");
      setStatus(`Заявка №${result.orderId} принята. Сохраните номер для уточнения статуса.`);
      setName(""); setContact(""); setDetails("");
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "Ошибка отправки. Попробуйте позже.");
    } finally { setBusy(false); }
  }

  return <main>
    <div className="wrap">
      <header className="topbar">
        <a className="logo" href="#"><span>VIP</span>STAR</a>
        <nav className="nav"><a href="#services">Услуги</a><a href="#how">Как заказать</a><a href="#order">Оставить заявку</a></nav>
        <a className="pill" href="#order">Мои заявки ↗</a>
      </header>
      <div className="hero">
        <div>
          <span className="eyebrow">DIGITAL • CONTENT • GROWTH</span>
          <h1>Продвижение,<br/>которое выглядит <em>профессионально.</em></h1>
          <p className="lead">VIPSTAR — каталог digital-услуг для авторов, проектов и небольших брендов. Выберите услугу, оставьте заявку и согласуйте детали перед оплатой.</p>
          <div className="actions"><a className="btn primary" href="#services">Выбрать услугу ↗</a><a className="btn secondary" href="#how">Как это работает</a></div>
        </div>
        <aside className="heroCard">
          <div className="small">ВАШ ПРОЕКТ — СЛЕДУЮЩИЙ УРОВЕНЬ</div>
          <div className="big">VIPSTAR</div>
          <p className="lead">Прозрачные условия, ручная проверка заказов и поддержка на каждом этапе.</p>
          <div className="stat"><span>Способ оплаты</span><strong>Kaspi · вручную</strong></div>
          <div className="stat"><span>Подтверждение</span><strong>Перед началом</strong></div>
          <div className="stat"><span>Поддержка</span><strong>По заявке</strong></div>
        </aside>
      </div>
      <section id="services">
        <div className="sectionHead"><div><h2>Каталог услуг</h2><p>Цены примерные — итог согласуется до оплаты.</p></div><span className="pill">6 категорий</span></div>
        <div className="grid">{services.map((service) => <article className="service" key={service.title}>
          <div className="emoji">{service.icon}</div><h3>{service.title}</h3><p>{service.desc}</p>
          <div className="bottom"><span className="price">{service.price}</span><button className="btn secondary" onClick={() => {setCategory(service.category); document.getElementById("order")?.scrollIntoView({behavior:"smooth"});}}>Заказать ↗</button></div>
        </article>)}</div>
      </section>
      <section id="how">
        <div className="sectionHead"><div><h2>Как это работает</h2><p>Без автоматического списания денег.</p></div></div>
        <div className="info"><strong>1.</strong> Вы отправляете заявку. <strong>2.</strong> Владелец проверяет задачу и подтверждает стоимость. <strong>3.</strong> После подтверждения вы оплачиваете через Kaspi по предоставленным реквизитам. <strong>4.</strong> Заказ выполняется и статус обновляется вручную. Не отправляйте пароли от социальных сетей и банковских приложений.</div>
      </section>
      <section id="order">
        <div className="sectionHead"><div><h2>Оставить заявку</h2><p>Укажите способ связи — владелец ответит и согласует детали.</p></div></div>
        <div className="order">
          <form className="formCard" onSubmit={submitOrder}>
            <h3>Новая заявка</h3>
            <div className="field"><label htmlFor="name">Ваше имя</label><input id="name" value={name} onChange={e=>setName(e.target.value)} required maxLength={80} placeholder="Как к вам обращаться"/></div>
            <div className="field"><label htmlFor="contact">Контакт для связи</label><input id="contact" value={contact} onChange={e=>setContact(e.target.value)} required maxLength={160} placeholder="@username или номер телефона"/></div>
            <div className="field"><label htmlFor="category">Услуга</label><select id="category" value={category} onChange={e=>setCategory(e.target.value)}>{services.map(s=><option key={s.category}>{s.category}</option>)}</select></div>
            <div className="field"><label htmlFor="details">Описание задачи</label><textarea id="details" value={details} onChange={e=>setDetails(e.target.value)} maxLength={1500} placeholder="Расскажите, что требуется (не указывайте пароли)"/></div>
            <button className="btn primary" disabled={busy} type="submit">{busy ? "Отправляем…" : "Отправить заявку"}</button>
            {status && <div className="status" role="status">{status}</div>}
            <p className="notice">Отправляя заявку, вы разрешаете использовать указанные данные для ответа по вашему запросу.</p>
          </form>
          <div className="info"><h3>Оплата Kaspi</h3><p>Оплата включается после того, как владелец подтвердит заявку и стоимость.</p><p><strong>Важно:</strong> этот стартовый проект не принимает онлайн-платежи автоматически. Не публикуйте номер карты или другие платёжные данные в открытом доступе.</p><p>После запуска добавим безопасную авторизацию, личный кабинет и защищённую панель владельца.</p></div>
        </div>
      </section>
      <footer className="footer"><span>© {new Date().getFullYear()} VIPSTAR</span><span>Digital-услуги • Поддержка клиентов</span></footer>
    </div>
  </main>;
}

import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const allowedCategories = [
  "Контент и оформление", "Монтаж коротких видео", "Аналитика соцсетей",
  "Дизайн публикаций", "Контент-план", "Консультация"
];

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = String(body.name ?? "").trim();
    const contact = String(body.contact ?? "").trim();
    const category = String(body.category ?? "").trim();
    const details = String(body.details ?? "").trim();

    if (name.length < 2 || name.length > 80) return NextResponse.json({ error: "Укажите имя (2–80 символов)." }, { status: 400 });
    if (contact.length < 3 || contact.length > 160) return NextResponse.json({ error: "Укажите контакт для связи." }, { status: 400 });
    if (!allowedCategories.includes(category)) return NextResponse.json({ error: "Выберите услугу из каталога." }, { status: 400 });
    if (details.length > 1500) return NextResponse.json({ error: "Описание слишком длинное." }, { status: 400 });

    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !key) return NextResponse.json({ error: "Приём заявок пока не настроен. Владелец должен подключить базу данных Supabase." }, { status: 503 });

    const supabase = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data, error } = await supabase.from("orders").insert({
      customer_name: name, contact, service_name: category, details: details || null, status: "new"
    }).select("id").single();

    if (error) {
      console.error("Order insert failed:", error.message);
      return NextResponse.json({ error: "Не удалось сохранить заявку. Попробуйте позже." }, { status: 500 });
    }
    return NextResponse.json({ ok: true, orderId: data.id });
  } catch {
    return NextResponse.json({ error: "Проверьте поля формы и попробуйте ещё раз." }, { status: 400 });
  }
}
